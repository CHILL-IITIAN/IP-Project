import os
import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
import pandas as pd
import matplotlib.pyplot as plt

# ==========================================
# SETUP AND CONFIGURATION
# ==========================================

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

FILE_NAME = os.path.join(os.path.dirname(__file__), "students.csv")
COLUMNS = [
    "Roll Number",
    "Name",
    "Class",
    "Section",
    "Gender",
    "Age",
    "English",
    "Physics",
    "Chemistry",
    "Mathematics",
    "Total Marks",
    "Percentage",
    "Grade",
]

if not os.path.exists(FILE_NAME):
    df = pd.DataFrame(columns=COLUMNS)
    df.to_csv(FILE_NAME, index=False)

app = ctk.CTk()
app.title("Student Management System")
app.geometry("1400x800")

# ==========================================
# HELPER FUNCTIONS
# ==========================================


def calculate_grade(percentage):
    if percentage >= 90:
        return "A+"
    elif percentage >= 80:
        return "A"
    elif percentage >= 70:
        return "B"
    elif percentage >= 60:
        return "C"
    elif percentage >= 40:
        return "D"
    else:
        return "F"


def clear_form():
    roll_var.set("")
    name_var.set("")
    class_var.set("12")
    section_var.set("A")
    gender_var.set("Male")
    age_var.set("")
    eng_var.set("")
    phy_var.set("")
    chem_var.set("")
    math_var.set("")


def refresh_table(search_df=None):
    for row in tree.get_children():
        tree.delete(row)

    try:
        if search_df is not None:
            df = search_df
        else:
            df = pd.read_csv(FILE_NAME)

        for _, row in df.iterrows():
            tree.insert("", "end", values=list(row))

        update_dashboard(df)
    except Exception as e:
        messagebox.showerror("Error", f"Could not load data: {e}")


def update_dashboard(df):
    if df.empty:
        kpi_total.configure(text="0")
        kpi_avg.configure(text="0.0%")
        kpi_topper.configure(text="N/A")
        kpi_pass.configure(text="0.0%")
        return

    total_students = len(df)
    avg_pct = df["Percentage"].mean()
    topper_name = df.loc[df["Percentage"].idxmax()]["Name"]
    pass_count = len(df[df["Grade"] != "F"])
    pass_pct = (pass_count / total_students) * 100

    kpi_total.configure(text=str(total_students))
    kpi_avg.configure(text=f"{avg_pct:.2f}%")
    kpi_topper.configure(text=str(topper_name))
    kpi_pass.configure(text=f"{pass_pct:.2f}%")


def get_form_data():
    try:
        roll = roll_var.get().strip()
        name = name_var.get().strip()
        cls = class_var.get()
        sec = section_var.get()
        gen = gender_var.get()
        age = age_var.get().strip()
        eng = eng_var.get().strip()
        phy = phy_var.get().strip()
        chem = chem_var.get().strip()
        math = math_var.get().strip()

        if not all([roll, name, cls, sec, gen, age, eng, phy, chem, math]):
            messagebox.showwarning("Warning", "All fields are required!")
            return None

        roll = int(roll)
        age = int(age)
        eng = float(eng)
        phy = float(phy)
        chem = float(chem)
        math = float(math)

        if age <= 0 or age > 100:
            messagebox.showerror("Error", "Please enter a valid age.")
            return None

        for mark in [eng, phy, chem, math]:
            if mark < 0 or mark > 100:
                messagebox.showerror("Error", "Marks must be between 0 and 100.")
                return None

        total = eng + phy + chem + math
        percentage = total / 4.0
        grade = calculate_grade(percentage)

        return {
            "Roll Number": roll,
            "Name": name,
            "Class": cls,
            "Section": sec,
            "Gender": gen,
            "Age": age,
            "English": eng,
            "Physics": phy,
            "Chemistry": chem,
            "Mathematics": math,
            "Total Marks": total,
            "Percentage": percentage,
            "Grade": grade,
        }
    except ValueError:
        messagebox.showerror("Error", "Roll Number, Age and Marks must be valid numbers!")
        return None


# ==========================================
# CRUD OPERATIONS
# ==========================================


def add_student():
    data = get_form_data()
    if data:
        df = pd.read_csv(FILE_NAME)

        if data["Roll Number"] in df["Roll Number"].values:
            messagebox.showerror("Error", "Student with this Roll Number already exists!")
            return

        df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
        df.to_csv(FILE_NAME, index=False)

        messagebox.showinfo("Success", "Student Added Successfully!")
        clear_form()
        refresh_table()


def update_student():
    data = get_form_data()
    if data:
        df = pd.read_csv(FILE_NAME)
        roll = data["Roll Number"]

        if roll not in df["Roll Number"].values:
            messagebox.showerror("Error", "Roll Number not found in database!")
            return

        df.loc[df["Roll Number"] == roll, list(data.keys())] = list(data.values())
        df.to_csv(FILE_NAME, index=False)

        messagebox.showinfo("Success", "Student Updated Successfully!")
        refresh_table()


def delete_student():
    try:
        roll = int(roll_var.get().strip())
        df = pd.read_csv(FILE_NAME)

        if roll not in df["Roll Number"].values:
            messagebox.showerror("Error", "Roll Number not found!")
            return

        confirm = messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this student?")
        if confirm:
            df = df[df["Roll Number"] != roll]
            df.to_csv(FILE_NAME, index=False)
            messagebox.showinfo("Success", "Student Deleted Successfully!")
            clear_form()
            refresh_table()
    except ValueError:
        messagebox.showerror("Error", "Please enter a valid Roll Number to delete.")


def import_csv():
    file_path = tk.filedialog.askopenfilename(
        title="Select CSV File",
        filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
    )
    if not file_path:
        return

    try:
        import_df = pd.read_csv(file_path)

        missing_cols = set(COLUMNS) - set(import_df.columns)
        if missing_cols:
            messagebox.showerror("Error", f"Missing required columns: {', '.join(missing_cols)}")
            return

        import_df = import_df[COLUMNS]

        for col in ["Roll Number", "Age"]:
            import_df[col] = pd.to_numeric(import_df[col], errors="coerce")
        for col in ["English", "Physics", "Chemistry", "Mathematics", "Total Marks", "Percentage"]:
            import_df[col] = pd.to_numeric(import_df[col], errors="coerce")

        if import_df.isnull().any().any():
            messagebox.showerror("Error", "CSV contains invalid or missing data in required fields.")
            return

        existing_df = pd.read_csv(FILE_NAME)
        duplicate_rolls = set(import_df["Roll Number"]).intersection(set(existing_df["Roll Number"]))
        if duplicate_rolls:
            messagebox.showerror("Error", f"Duplicate Roll Numbers found: {', '.join(map(str, duplicate_rolls))}")
            return

        combined_df = pd.concat([existing_df, import_df], ignore_index=True)
        combined_df.to_csv(FILE_NAME, index=False)

        messagebox.showinfo("Success", f"Imported {len(import_df)} students successfully!")
        refresh_table()
    except Exception as e:
        messagebox.showerror("Error", f"Failed to import CSV: {e}")


def search_student():
    query = search_var.get().strip().lower()
    if not query:
        refresh_table()
        return

    df = pd.read_csv(FILE_NAME)
    filtered_df = df[
        df["Roll Number"].astype(str).str.contains(query) |
        df["Name"].str.lower().str.contains(query)
    ]
    refresh_table(filtered_df)


def fill_form_from_tree(event):
    selected_item = tree.selection()
    if selected_item:
        values = tree.item(selected_item[0], "values")
        if values:
            roll_var.set(values[0])
            name_var.set(values[1])
            class_var.set(values[2])
            section_var.set(values[3])
            gender_var.set(values[4])
            age_var.set(values[5])
            eng_var.set(values[6])
            phy_var.set(values[7])
            chem_var.set(values[8])
            math_var.set(values[9])


# ==========================================
# ANALYTICS & GRAPHS FUNCTIONS
# ==========================================


def show_analytics(action):
    df = pd.read_csv(FILE_NAME)
    if df.empty:
        messagebox.showinfo("Info", "No data available.")
        return

    result = ""
    if action == "Class Average":
        result = df.groupby("Class")["Percentage"].mean().to_string()
    elif action == "Topper":
        topper = df.loc[df["Percentage"].idxmax()]
        result = f"Name: {topper['Name']}\nPercentage: {topper['Percentage']}%\nClass: {topper['Class']}"
    elif action == "Lowest Scorer":
        lowest = df.loc[df["Percentage"].idxmin()]
        result = f"Name: {lowest['Name']}\nPercentage: {lowest['Percentage']}%\nClass: {lowest['Class']}"
    elif action == "Top 5":
        top5 = df.nlargest(5, "Percentage")[["Name", "Class", "Percentage"]]
        result = top5.to_string(index=False)
    elif action == "Bottom 5":
        bot5 = df.nsmallest(5, "Percentage")[["Name", "Class", "Percentage"]]
        result = bot5.to_string(index=False)
    elif action == "Subject Avg":
        subs = df[["English", "Physics", "Chemistry", "Mathematics"]].mean()
        result = subs.to_string()
    elif action == "Pass Count":
        count = len(df[df["Grade"] != "F"])
        result = f"Total Passed: {count}"
    elif action == "Fail Count":
        count = len(df[df["Grade"] == "F"])
        result = f"Total Failed: {count}"
    elif action == "Pass Pct":
        count = len(df[df["Grade"] != "F"])
        pct = (count / len(df)) * 100
        result = f"Pass Percentage: {pct:.2f}%"
    elif action == "Grade Dist":
        dist = df["Grade"].value_counts()
        result = dist.to_string()

    messagebox.showinfo(action, result)


def plot_graph(graph_type):
    df = pd.read_csv(FILE_NAME)
    if df.empty:
        messagebox.showinfo("Info", "No data to plot.")
        return

    plt.figure(figsize=(8, 5))

    if graph_type == "Top Students":
        top_students = df.nlargest(5, "Percentage")
        plt.bar(top_students["Name"], top_students["Percentage"], color=["blue", "green", "red", "purple", "orange"])
        plt.title("Top 5 Students by Percentage")
        plt.xlabel("Student Name")
        plt.ylabel("Percentage (%)")
    elif graph_type == "Subject Average":
        averages = df[["English", "Physics", "Chemistry", "Mathematics"]].mean()
        plt.bar(averages.index, averages.values, color=["skyblue", "lightgreen", "salmon", "plum"])
        plt.title("Class Average in Each Subject")
        plt.xlabel("Subjects")
        plt.ylabel("Average Marks")
    elif graph_type == "Grade Distribution":
        grade_counts = df["Grade"].value_counts()
        plt.pie(grade_counts.values, labels=grade_counts.index, autopct="%1.1f%%", startangle=140)
        plt.title("Grade Distribution of Students")

    plt.tight_layout()
    plt.show()


# ==========================================
# GUI LAYOUT DESIGN
# ==========================================

header_frame = ctk.CTkFrame(app, fg_color="transparent")
header_frame.pack(fill="x", pady=10)

ctk.CTkLabel(header_frame, text="STUDENT MANAGEMENT SYSTEM", font=("Arial", 32, "bold")).pack()
ctk.CTkLabel(header_frame, text="CBSE Informatics Practices Project", font=("Arial", 16)).pack()

kpi_frame = ctk.CTkFrame(app)
kpi_frame.pack(fill="x", padx=20, pady=10)


def create_kpi_card(parent, title):
    card = ctk.CTkFrame(parent, fg_color="#2b2b2b", corner_radius=10)
    card.pack(side="left", fill="both", expand=True, padx=10, pady=10)
    ctk.CTkLabel(card, text=title, font=("Arial", 14)).pack(pady=(10, 0))
    val_label = ctk.CTkLabel(card, text="-", font=("Arial", 24, "bold"), text_color="#1f6aa5")
    val_label.pack(pady=(5, 10))
    return val_label


kpi_total = create_kpi_card(kpi_frame, "Total Students")
kpi_avg = create_kpi_card(kpi_frame, "Average Percentage")
kpi_topper = create_kpi_card(kpi_frame, "Topper Name")
kpi_pass = create_kpi_card(kpi_frame, "Pass Percentage")

main_frame = ctk.CTkFrame(app, fg_color="transparent")
main_frame.pack(fill="both", expand=True, padx=20, pady=10)

form_frame = ctk.CTkFrame(main_frame, width=350)
form_frame.pack(side="left", fill="y", padx=(0, 10))

ctk.CTkLabel(form_frame, text="Student Details Form", font=("Arial", 20, "bold")).pack(pady=15)

roll_var = tk.StringVar()
name_var = tk.StringVar()
class_var = tk.StringVar(value="12")
section_var = tk.StringVar(value="A")
gender_var = tk.StringVar(value="Male")
age_var = tk.StringVar()
eng_var = tk.StringVar()
phy_var = tk.StringVar()
chem_var = tk.StringVar()
math_var = tk.StringVar()


def make_entry(parent, label, variable, is_combo=False, combo_values=None):
    frame = ctk.CTkFrame(parent, fg_color="transparent")
    frame.pack(fill="x", padx=20, pady=5)
    ctk.CTkLabel(frame, text=label, width=100, anchor="w").pack(side="left")
    if is_combo:
        comp = ctk.CTkComboBox(frame, variable=variable, values=combo_values, width=180)
    else:
        comp = ctk.CTkEntry(frame, textvariable=variable, width=180)
    comp.pack(side="right")


make_entry(form_frame, "Roll Number:", roll_var)
make_entry(form_frame, "Student Name:", name_var)
make_entry(form_frame, "Class:", class_var, True, ["11", "12"])
make_entry(form_frame, "Section:", section_var, True, ["A", "B", "C", "D"])
make_entry(form_frame, "Gender:", gender_var, True, ["Male", "Female", "Other"])
make_entry(form_frame, "Age:", age_var)
make_entry(form_frame, "English Marks:", eng_var)
make_entry(form_frame, "Physics Marks:", phy_var)
make_entry(form_frame, "Chemistry Marks:", chem_var)
make_entry(form_frame, "Maths Marks:", math_var)

btn_frame = ctk.CTkFrame(form_frame, fg_color="transparent")
btn_frame.pack(pady=20)

ctk.CTkButton(btn_frame, text="Add", width=80, command=add_student).grid(row=0, column=0, padx=5, pady=5)
ctk.CTkButton(btn_frame, text="Update", width=80, command=update_student).grid(row=0, column=1, padx=5, pady=5)
ctk.CTkButton(btn_frame, text="Delete", width=80, fg_color="red", hover_color="darkred", command=delete_student).grid(row=0, column=2, padx=5, pady=5)
ctk.CTkButton(btn_frame, text="Import CSV", width=80, fg_color="#2e7d32", hover_color="#1b5e20", command=import_csv).grid(row=0, column=3, padx=5, pady=5)
ctk.CTkButton(btn_frame, text="Clear Fields", width=260, fg_color="gray", command=clear_form).grid(row=1, column=0, columnspan=4, pady=5)

right_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
right_frame.pack(side="right", fill="both", expand=True)

search_frame = ctk.CTkFrame(right_frame, fg_color="transparent")
search_frame.pack(fill="x", pady=(0, 10))

search_var = tk.StringVar()
ctk.CTkEntry(search_frame, textvariable=search_var, placeholder_text="Search by Name or Roll Number", width=300).pack(side="left", padx=(0, 10))
ctk.CTkButton(search_frame, text="Search", width=100, command=search_student).pack(side="left", padx=5)
ctk.CTkButton(search_frame, text="View All", width=100, fg_color="gray", command=lambda: [search_var.set(""), refresh_table()]).pack(side="left", padx=5)

style = ttk.Style()
style.theme_use("default")
style.configure("Treeview", background="#2b2b2b", foreground="white", rowheight=25, fieldbackground="#2b2b2b", borderwidth=0)
style.map("Treeview", background=[("selected", "#1f6aa5")])
style.configure("Treeview.Heading", background="#1f1f1f", foreground="white", font=("Arial", 10, "bold"))

tree_frame = ctk.CTkFrame(right_frame)
tree_frame.pack(fill="both", expand=True)

scroll_y = ttk.Scrollbar(tree_frame, orient="vertical")
scroll_x = ttk.Scrollbar(tree_frame, orient="horizontal")

tree = ttk.Treeview(tree_frame, columns=COLUMNS, show="headings", yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
scroll_y.config(command=tree.yview)
scroll_x.config(command=tree.xview)

scroll_y.pack(side="right", fill="y")
scroll_x.pack(side="bottom", fill="x")
tree.pack(fill="both", expand=True)

for col in COLUMNS:
    tree.heading(col, text=col)
    tree.column(col, width=90, anchor="center")

tree.bind("<<TreeviewSelect>>", fill_form_from_tree)

bottom_panel = ctk.CTkFrame(right_frame, fg_color="transparent")
bottom_panel.pack(fill="x", pady=10)

analytics_lbl = ctk.CTkLabel(bottom_panel, text="Data Analytics & Reports", font=("Arial", 16, "bold"))
analytics_lbl.pack(pady=(0, 5))

an_frame = ctk.CTkFrame(bottom_panel, fg_color="transparent")
an_frame.pack()

analytics_list = [
    "Class Average",
    "Topper",
    "Lowest Scorer",
    "Top 5",
    "Bottom 5",
    "Subject Avg",
    "Pass Count",
    "Fail Count",
    "Pass Pct",
    "Grade Dist",
]

row_val = 0
col_val = 0
for item in analytics_list:
    ctk.CTkButton(
        an_frame,
        text=item,
        width=110,
        fg_color="#3a3a3a",
        hover_color="#4a4a4a",
        command=lambda txt=item: show_analytics(txt),
    ).grid(row=row_val, column=col_val, padx=5, pady=5)
    col_val += 1
    if col_val > 4:
        col_val = 0
        row_val += 1

graph_frame = ctk.CTkFrame(bottom_panel, fg_color="transparent")
graph_frame.pack(pady=10)

ctk.CTkButton(graph_frame, text="📊 Top Students Chart", width=180, fg_color="#1f6aa5", command=lambda: plot_graph("Top Students")).pack(side="left", padx=10)
ctk.CTkButton(graph_frame, text="📊 Subject Average Chart", width=180, fg_color="#1f6aa5", command=lambda: plot_graph("Subject Average")).pack(side="left", padx=10)
ctk.CTkButton(graph_frame, text="🥧 Grade Distribution Pie", width=180, fg_color="#1f6aa5", command=lambda: plot_graph("Grade Distribution")).pack(side="left", padx=10)

refresh_table()

if __name__ == "__main__":
    app.mainloop()